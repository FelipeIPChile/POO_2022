/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cl.ipchile.java.utils;

/**
 *
 * @author felip
 */
public class Utils {
    String dbURL = "jdbc:derby://localhost:1527/DBIPCHILE; createFrom = C:\\DBIPCHILE";
    String user = "DBIPCHILE";
    String pass = "DBIPCHILE";


    public void setDbURL(String dbURL) {
        this.dbURL = dbURL;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getDbURL() {
        return dbURL;
    }

    public String getUser() {
        return user;
    }

    public String getPass() {
        return pass;
    }
    
    
    
   
}
