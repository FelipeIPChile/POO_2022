/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cl.ip.chile.poo;

/**
 *
 * @author felip
 */
public class Profesores {

    private String id_profesor;
    private String nombre;
    private String paterno;
    private String materno;

    public Profesores(){
    }
    
    public Profesores(String id_profesor, String nombre, String paterno, String materno){
        this.id_profesor    = id_profesor;
        this.nombre         = nombre;
        this.paterno        = paterno;
        this.materno        = materno;
        
    }
    /**
     * @return the id_profesor
     */
    public String getId_profesor() {
        return id_profesor;
    }

    /**
     * @param id_profesor the id_profesor to set
     */
    public void setId_profesor(String id_profesor) {
        this.id_profesor = id_profesor;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the paterno
     */
    public String getPaterno() {
        return paterno;
    }

    /**
     * @param paterno the paterno to set
     */
    public void setPaterno(String paterno) {
        this.paterno = paterno;
    }

    /**
     * @return the materno
     */
    public String getMaterno() {
        return materno;
    }

    /**
     * @param materno the materno to set
     */
    public void setMaterno(String materno) {
        this.materno = materno;
    }

    public String toString(){
        return nombre + " " + paterno + " " + materno;
    }
}
