/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cl.ip.chile.poo;

/**
 *
 * @author felip
 */
public class Utils {
    String url      = "jdbc:derby://localhost:1527/DBIPCHILE";
    String user     = "DBIPCHILE";
    String password = "DBIPCHILE";
    
    String queryProfesores = "SELECT * FROM PROFESORES";
}
